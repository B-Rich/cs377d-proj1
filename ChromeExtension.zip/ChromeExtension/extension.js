//var server = "https://mailfoogae.appspot.com";

var server = "https://lime-time.appspot.com";
//var server = "https://localhost";

var extVersion = "5.0";
var combinedPath = "/build/";
